from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
import os
import numpy as np
from utils.Evaluator import Evaluator
import torch
import torch.nn as nn
from utils.img_read_save import img_save,image_read_cv2
import warnings
import logging
import kornia
import torch.nn.functional as F
warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.CRITICAL)

os.environ["CUDA_VISIBLE_DEVICES"] = "1"
ckpt_path=r"models/CDDFuse_IVF.pth"
#for dataset_name in ["TNO","RoadScene","LLVIP"]:
dataset_name = "MSRS"
print("\n"*2+"="*80)
model_name="CDDFuse"
print("The test result of "+dataset_name+' :')
test_folder=os.path.join('test_img',dataset_name) 
test_out_folder=os.path.join('test_result',dataset_name,'loss_uni_50_now')

device = 'cuda' if torch.cuda.is_available() else 'cpu'
Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)

Encoder.load_state_dict(torch.load(ckpt_path)['DIDF_Encoder'])
Decoder.load_state_dict(torch.load(ckpt_path)['DIDF_Decoder'])
BaseFuseLayer.load_state_dict(torch.load(ckpt_path)['BaseFuseLayer'])
DetailFuseLayer.load_state_dict(torch.load(ckpt_path)['DetailFuseLayer'])
Encoder.eval()
Decoder.eval()
BaseFuseLayer.eval()
DetailFuseLayer.eval()
Loss_ssim = kornia.losses.SSIM(11, reduction='none')
def vision_features(feature_map,img_type,name):
    count = 0
    # for features in feature_maps:
    count += 1
    root = os.path.join('Maps','LLVIP','loss_uni_50_now')
    output_path = root+'/'+img_type +'/'
    if not os.path.exists(root):
      os.mkdir(root)
    if not os.path.exists(output_path):
      os.mkdir(output_path)
    # print(feature_map.shape)
    map = torch.mean(feature_map,1)
    map=(map-torch.min(map))/(torch.max(map)-torch.min(map))
    map = np.squeeze((map * 255).cpu().numpy())
    img_save(map, name.split(sep='.')[0], output_path)

class GradLoss(nn.Module):
    def __init__(self):
        super(GradLoss, self).__init__()
        self.sobelconv=Sobelxy()

    def forward(self,image_A,image_B):
        image_A_grad=self.sobelconv(image_A)
        image_B_grad=self.sobelconv(image_B)
        grad_loss = torch.abs(image_A_grad-image_B_grad)
        return grad_loss

class Sobelxy(nn.Module):
    def __init__(self):
        super(Sobelxy, self).__init__()
        kernelx = [[-1, 0, 1],
                  [-2,0 , 2],
                  [-1, 0, 1]]
        kernely = [[1, 2, 1],
                  [0,0 , 0],
                  [-1, -2, -1]]
        kernelx = torch.FloatTensor(kernelx).unsqueeze(0).unsqueeze(0)
        kernely = torch.FloatTensor(kernely).unsqueeze(0).unsqueeze(0)
        self.weightx = nn.Parameter(data=kernelx, requires_grad=False).cuda()
        self.weighty = nn.Parameter(data=kernely, requires_grad=False).cuda()
    def forward(self,x):
        sobelx=F.conv2d(x, self.weightx, padding=1)
        sobely=F.conv2d(x, self.weighty, padding=1)
        return torch.abs(sobelx)+torch.abs(sobely)

with torch.no_grad():
    mse = nn.MSELoss(reduction='none')
    mae = nn.L1Loss(reduction='none')
    gradloss = GradLoss()
    for img_name in os.listdir(os.path.join(test_folder,"ir")):
        print(img_name)
        # data_VIS_gray = image_read_cv2(os.path.join(test_folder,"A",img_name), mode='GRAY')
        # img_save(data_VIS_gray, img_name.split(sep='.')[0]+'gray', 'Gray_vis')
        data_IR=image_read_cv2(os.path.join(test_folder,"ir",img_name),mode='GRAY')[np.newaxis,np.newaxis, ...]/255.0
        data_VIS = image_read_cv2(os.path.join(test_folder,"vi",img_name), mode='GRAY')[np.newaxis,np.newaxis, ...]/255.0

        data_IR,data_VIS = torch.FloatTensor(data_IR),torch.FloatTensor(data_VIS)
        data_VIS, data_IR = data_VIS.cuda(), data_IR.cuda()
        # epoch = 5
        feature_B_V_ori, feature_D_V_ori, feature_V = Encoder(data_VIS)
        feature_B_I_ori, feature_D_I_ori, feature_I = Encoder(data_IR)
        # visual
        feature_B_V = BaseFuseLayer(feature_B_V_ori)
        feature_D_V = DetailFuseLayer(feature_D_V_ori)
        # infrared
        feature_B_I = BaseFuseLayer(feature_B_I_ori)
        feature_D_I = DetailFuseLayer(feature_D_I_ori)
        data_v, _ = Decoder(None, feature_B_V, feature_D_V)
        # loss_v = mse(data_v,data_VIS)+torch.abs(data_v-data_VIS)
        data_i, _ = Decoder(None, feature_B_I, feature_D_I)
        # loss_i = mse(data_i,data_IR)+torch.abs(data_i-data_IR)
        loss_r_r = mse(data_i,data_IR)
        loss_v_v = mse(data_v,data_VIS)
        # loss_r_v = mse(data_i,data_VIS)
        # loss_v_r = mse(data_v,data_IR)
        # print('loss_r_r:',loss_r_r,'loss_v_v:',loss_v_v,'loss_r_v:',loss_r_v,'loss_v_r:',loss_v_r)
        print('loss_r_r:',loss_r_r,'loss_v_v:',loss_v_v)
        # w_i = - loss_r_r 
        # w_v = - loss_v_v
        # w_i = loss_v_r
        # w_v = loss_r_v
        
        # vision_features(data_i, 'data_i',img_name)
        # vision_features(data_v,'data_v',img_name)
        # vision_features(loss_r_r, 'loss_i',img_name)
        # vision_features(loss_v_v,'loss_v',img_name)
        # fuse
        # softmax = nn.Softmax(0)
        # loss = torch.stack([loss_r_r*100,loss_v_v*100])
        # loss = softmax(loss)
        # loss_r_r = loss[0]
        # loss_v_v = loss[1]

        w_i = torch.exp(-loss_r_r*50)
        w_v = torch.exp(-loss_v_v*50)
        
        softmax = nn.Softmax(0)
        w = torch.stack([w_i,w_v])
        w = softmax(w)
        w_i = 2*w[0]
        w_v = 2*w[1]
        print('w_i:',w_i,'w_v:',w_v)
        vision_features(data_v, 'data_v',img_name)
        vision_features(data_i, 'data_i',img_name)
        vision_features(w_i, 'w_i',img_name)
        vision_features(w_v, 'w_v',img_name)
        # w_i = 2*w_i/(w_i+ w_v)
        # w_v = 2*w_v/(w_i+ w_v)
        feature_B = torch.mul(w_i,feature_B_I_ori) + torch.mul(w_v,feature_B_V_ori)
        feature_D = torch.mul(w_i,feature_D_I_ori) + torch.mul(w_v,feature_D_V_ori)
        feature_F_B = BaseFuseLayer(feature_B)
        feature_F_D = DetailFuseLayer(feature_D)
        data_Fuse, _ = Decoder(data_VIS, feature_F_B, feature_F_D)
        data_Fuse=(data_Fuse-torch.min(data_Fuse))/(torch.max(data_Fuse)-torch.min(data_Fuse))
        fi = np.squeeze((data_Fuse * 255).cpu().numpy())
        img_save(fi, img_name.split(sep='.')[0], test_out_folder)
          
               
eval_folder=test_out_folder  
ori_img_folder=test_folder

# metric_result = np.zeros((8))
# for img_name in os.listdir(os.path.join(ori_img_folder,"ir")):
#         ir = image_read_cv2(os.path.join(ori_img_folder,"ir", img_name), 'GRAY')
#         vi = image_read_cv2(os.path.join(ori_img_folder,"vi", img_name), 'GRAY')
#         fi = image_read_cv2(os.path.join(eval_folder, img_name.split('.')[0]+".png"), 'GRAY')
#         metric_result += np.array([Evaluator.EN(fi), Evaluator.SD(fi)
#                                     , Evaluator.SF(fi), Evaluator.MI(fi, ir, vi)
#                                     , Evaluator.SCD(fi, ir, vi), Evaluator.VIFF(fi, ir, vi)
#                                     , Evaluator.Qabf(fi, ir, vi), Evaluator.SSIM(fi, ir, vi)])

# metric_result /= len(os.listdir(eval_folder))
# print("\t\t EN\t SD\t SF\t MI\tSCD\tVIF\tQabf\tSSIM")
# print(model_name+'\t'+str(np.round(metric_result[0], 2))+'\t'
#         +str(np.round(metric_result[1], 2))+'\t'
#         +str(np.round(metric_result[2], 2))+'\t'
#         +str(np.round(metric_result[3], 2))+'\t'
#         +str(np.round(metric_result[4], 2))+'\t'
#         +str(np.round(metric_result[5], 2))+'\t'
#         +str(np.round(metric_result[6], 2))+'\t'
#         +str(np.round(metric_result[7], 2))
#         )
print("="*80)